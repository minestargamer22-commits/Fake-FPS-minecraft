package com.realfps;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class RealFpsClient implements ClientModInitializer {
    private static KeyBinding menuKey;

    // Our own frame counter, so other FPS mods can't change what we read.
    private static int frames = 0;
    private static long windowStart = System.nanoTime();
    private static int realFps = 0;

    public static int getRealFps() {
        return realFps;
    }

    private static void countFrame() {
        frames++;
        long now = System.nanoTime();
        long elapsed = now - windowStart;
        if (elapsed >= 500_000_000L) {
            realFps = (int) Math.round(frames * 1_000_000_000.0 / elapsed);
            frames = 0;
            windowStart = now;
        }
    }

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("realfps", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.realfps.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new RealFpsScreen());
                } else if (client.currentScreen instanceof RealFpsScreen) {
                    client.setScreen(null);
                }
            }
        });

        // Counts every rendered frame in-game (draws nothing).
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("realfps", "counter"),
                (context, tickCounter) -> countFrame());
    }
}
