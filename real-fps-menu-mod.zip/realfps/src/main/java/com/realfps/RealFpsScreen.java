package com.realfps;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class RealFpsScreen extends Screen {
    public RealFpsScreen() {
        super(Text.literal("Real FPS"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int cy = this.height / 2;
        context.fill(cx - 80, cy - 34, cx + 80, cy + 34, 0xC0000000);
        context.drawCenteredTextWithShadow(this.textRenderer, "Real FPS", cx, cy - 22, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, String.valueOf(RealFpsClient.getRealFps()), cx, cy - 6, 0xFF55FFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, "ESC to close", cx, cy + 14, 0xFFAAAAAA);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
