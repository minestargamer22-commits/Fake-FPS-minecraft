package com.fakefps;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class FakeFpsClient implements ClientModInitializer {
    public static final int MIN_FAKE = 590;
    private static final Random RNG = new Random();
    private static int fakeFps = MIN_FAKE + 20;
    private static long lastUpdate = 0;

    private static KeyBinding menuKey;

    public static int getFakeFps() {
        long now = System.currentTimeMillis();
        if (now - lastUpdate > 250) {
            lastUpdate = now;
            int real = MinecraftClient.getInstance().getCurrentFps();
            // never below 590; wobbles a little so it looks natural
            int base = Math.max(MIN_FAKE + 15, real + 400);
            fakeFps = Math.max(MIN_FAKE, base + RNG.nextInt(41) - 20);
        }
        return fakeFps;
    }

    public static int getRealFps() {
        return MinecraftClient.getInstance().getCurrentFps();
    }

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("fakefps", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.fakefps.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new RealFpsScreen());
                }
            }
        });

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("fakefps", "hud"),
                (context, tickCounter) -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc.options.hudHidden) return;
                    context.drawTextWithShadow(mc.textRenderer, "FPS: " + getFakeFps(), 4, 4, 0xFF55FF55);
                });
    }
}
