package com.fakefps;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class RealFpsScreen extends Screen {
    public RealFpsScreen() {
        super(Text.literal("Real FPS"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int cy = this.height / 2;
        context.fill(cx - 90, cy - 40, cx + 90, cy + 40, 0xC0000000);
        context.drawCenteredTextWithShadow(this.textRenderer, "Real FPS", cx, cy - 28, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, String.valueOf(FakeFpsClient.getRealFps()), cx, cy - 10, 0xFF55FFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, "Displayed: " + FakeFpsClient.getFakeFps(), cx, cy + 10, 0xFF55FF55);
        context.drawCenteredTextWithShadow(this.textRenderer, "ESC to close", cx, cy + 26, 0xFFAAAAAA);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
